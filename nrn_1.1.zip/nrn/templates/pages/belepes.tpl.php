     <article>
          <form action = "?oldal=belep" method = "post" id="login">
            <fieldset>
              <legend>Bejelentkezés</legend>
              <label for="username">Felhasználónév</label><br><input type="text" name="username" id="username" required><br>
              <label for="jelszo">Jelszó</label><br><input type="password" name="jelszo" id="jeslzo" required><br>
              <input type="submit" name="belepes" value="Belépés">
            </fieldset>
          </form>
        </article>
        <article>
          <form action = "?oldal=regisztral" method = "post" id="registration">
            <fieldset>
                <legend>Regisztáció</legend>
                <label for="f_name">Vezeték név</label><br><input type="text" name="f_name" id="f_name" required><br>
                <label for="l_name">Kereszt név</label><br><input type="text" name="l_name" id="l_name" required><br>
                <label for="email">Email cím</label><br><input type="email" name="email" id="email" required><br>
                <label for="phone">Telefonszám</label><br><input type="num" name="phone" id="phone" required><br>
                <label for="rusername">Felhasználónév</label><br><input type="text" name="rusername" id="rusername" required><br>
                <label for="rpassword1">Jelszó</label><br><input type="password" name="rpassword1" id="rpassword1" required><br>
                <label for="rpassword2">Jelszó újra</label><br><input type="password" name="rpassword2" id="rpassword2" required><br>
                 <input type="submit" name="regisztracio" value="Regisztráció">
            </fieldset>
          </form>
        </article>
