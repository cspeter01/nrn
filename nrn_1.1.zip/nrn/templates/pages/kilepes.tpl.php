<article class="formed">
	<h1>Kilépett:</h1>
<?= $data['csn']." ".$data['un']." (".$data['login'].")" ?>
</article>