        <article>
          <h2>Üdvözöljük weboldalunkon!</h2>
          <p>
            Tisztelt Hölgyem/Uram!
          </p>
          <p>
            Köszöntöm a Nemzeti Reorganizációs Nonprofit Kft. weboldalán. Társaságunk a stratégiailag kiemelt jelentõségû gazdálkodó szervezetek csõdeljárásában és felszámolási eljárásában kerül kijelölésre vagyonfelügyelõként, ideiglenes vagyonfelügyelõként, rendkívüli vagyonfelügyelõként, illetve felszámolóként.
          </p>
          <p>
            Bízom benne, hogy weboldalunkon megtalálja azt Önt érdeklő információkat, esetleges kérdése esetén kérem, hogy keresse ügyfélszolgálatunkat, ahol munkatársaim készséggel állnak rendelkezésére.
          </p>
          <p>
            <img src="images/pages/drkcs.png">
          </p>
          <p>
            Dr. Kovács Csaba<br>
            ügyvezető<br>
            Nemzeti Reorganizációs Nonprofit Kft.<br>
          </p>
        </article>
