<?php session_start(); ?>
<?php if(file_exists('./logicals/'.$keres['fajl'].'.php')) { include("./logicals/{$keres['fajl']}.php"); } ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?= $ablakcim['cim'] . ( (isset($ablakcim['mottó'])) ? ('|' . $ablakcim['mottó']) : '' ) ?></title>
  <link href="styles/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div class="wrapper">
        <nav>
                <ul>
					<?php foreach ($oldalak as $url => $oldal) { ?>
						<?php if(! isset($_SESSION['login']) && $oldal['menun'][0] || isset($_SESSION['login']) && $oldal['menun'][1]) { ?>
							<li<?= (($oldal == $keres) ? ' class="active"' : '') ?>>
							<a href="<?= ($url == '/') ? '.' : ('?oldal=' . $url) ?>">
							<?= $oldal['szoveg'] ?></a>
							</li>
						<?php } ?>
					<?php } ?>
                </ul>
                <div class="login_data">
              <?php if(isset($_SESSION['login'])) { ?>Bejlentkezve: <strong><?= $_SESSION['csn']." ".$_SESSION['un']." (".$_SESSION['login'].")" ?></strong><?php } ?>
                </div>
            </nav>
         <div class="main" id="main">
      		<aside id="aside">
        		<section align="center">
          			<h2>Keresés a weblapon</h2>
                <form action="https://www.google.com/search" class="searchform" method="get" name="searchform" target="_blank">
                  <input name="sitesearch" type="hidden" value="">
                  <input autocomplete="on" class="form-control search" name="q" placeholder="Keresés" required="required"  type="text">
                  <button class="button" type="submit">Keresés</button>
                </form>
        		</section>
        		<section>
          			<img src="images/pages/open01.png">
        		</section>
        		<section>
          			<h2>Ha kérdése van...</h2>
          			<p>Telefon:<br>
            		+36 30 923 6508, +36 30 923 6578<br></p>
          			<p>Fax:<br>
            		(+36 1) 210-0425<br></p>
          			<p>Email:<br>
           			info@nrn.hu<br></p>
        		</section>
      		</aside>
      <div class="content">
              <?php include("./templates/pages/{$keres['fajl']}.tpl.php"); ?>
      </div>
    </div>
    <footer>
        <?php if(isset($lablec['copyright'])) { ?>&copy;&nbsp;<?= $lablec['copyright'] ?> <?php } ?>
		&nbsp;
        <?php if(isset($lablec['ceg'])) { ?><?= $lablec['ceg']; ?><?php } ?>
    </footer>
</body>
<script type="text/javascript" src="includes/js.js"></script>
</html>
