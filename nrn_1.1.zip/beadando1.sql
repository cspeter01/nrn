-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Gép: mysql.omega:3306
-- Létrehozás ideje: 2019. Máj 06. 10:41
-- Kiszolgáló verziója: 5.6.44-log
-- PHP verzió: 7.0.33-0+deb9u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `beadando1`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `felhasznalo`
--

CREATE TABLE `felhasznalo` (
  `id` int(11) NOT NULL,
  `vezeteknev` varchar(20) NOT NULL,
  `keresztnev` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `telefonszam` varchar(11) NOT NULL,
  `felhasznalonev` varchar(20) NOT NULL,
  `jelszo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `felhasznalo`
--

INSERT INTO `felhasznalo` (`id`, `vezeteknev`, `keresztnev`, `email`, `telefonszam`, `felhasznalonev`, `jelszo`) VALUES
(1, 'Csete', 'Péter', 'csete.peter1@gmail.com', '+3620222864', 'csetepeter', '04bab00df4b5fb35b9e6e8801b29ab1d84bb3f95'),
(2, 'Szarvas', 'Martin', 'szarvas.martin0@gmail.com', '06304538743', 'szarvasmartin', '04bab00df4b5fb35b9e6e8801b29ab1d84bb3f95');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `uzenetek`
--

CREATE TABLE `uzenetek` (
  `id` int(11) NOT NULL,
  `nev` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `uzenet` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- A tábla adatainak kiíratása `uzenetek`
--

INSERT INTO `uzenetek` (`id`, `nev`, `email`, `uzenet`) VALUES
(1, 'Csete Péter', 'csete.peter1@gmail.com', 'Teszt üzenet'),
(2, 'Monori Szabolcs', 'monori.szabolcs@gmail.com', 'Kacsa'),
(3, 'Csete Péter', 'csete.peter1@gmail.com', 'Másik teszt üzenet'),
(4, 'Cséplő Máté', 'f1mate1111@gmail.com', 'Szép munka!'),
(5, 'dgf', 'dsfg@dfh.hu', 'gdf'),
(6, 'Kerekes Patrik', 'ismeretlen@citromail.hu', 'Szép!');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `felhasznalo`
--
ALTER TABLE `felhasznalo`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `uzenetek`
--
ALTER TABLE `uzenetek`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `felhasznalo`
--
ALTER TABLE `felhasznalo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT a táblához `uzenetek`
--
ALTER TABLE `uzenetek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
