		<?php
        $dbh = new PDO('mysql:host=localhost;port=8889;dbname=beadando1', 'beadando1', 'jelszo123',
                        array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
        $dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');

        if(isset($_POST['kuld2'])){
        	$sqlInsert = "insert into uzenetek(id, nev, email, uzenet)
                          values(0, :nev, :email, :uzenet)";
            $stmt = $dbh->prepare($sqlInsert); 
            $stmt->execute(array(':nev' => $_POST['nev2'], ':email' => $_POST['email2'],
                                 ':uzenet' => $_POST['uzenet2'])); 
        }
        ?>
		


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
</head>
<body>
<?php
	if(isset($_POST['kuld2'])){
		echo "Név: ";
		echo $_POST['nev2'];
		echo "<br>";

		echo "Email: ";
		echo $_POST['email2'];
		echo "<br>";

		echo "Üzenet: ";
		echo $_POST['uzenet2'];
		echo "<br>";

	}
?>
</body>
</html>