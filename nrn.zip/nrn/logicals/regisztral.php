<?php
if(isset($_POST['f_name']) && isset($_POST['l_name']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['rusername']) && isset($_POST['rpassword1']) && isset($_POST['rpassword2'])) {
    try {
        // Kapcsolódás
        $dbh = new PDO('mysql:host=localhost;port=8889;dbname=beadando1', 'beadando1', 'jelszo123',
                        array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
        $dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
        
        // Létezik már a felhasználói név?
        $sqlSelect = "select id from felhasznalo where felhasznalonev = :felhasznalonev";
        $sth = $dbh->prepare($sqlSelect);
        $sth->execute(array(':felhasznalonev' => $_POST['rusername']));
        if($row = $sth->fetch(PDO::FETCH_ASSOC)) {
            $uzenet = "A felhasználói név már foglalt!";
            $ujra = "true";
        }
        else {
            if (isset($_POST['rpassword1']) === isset($_POST['rpassword2'])){
            // Ha nem létezik, akkor regisztráljuk
            $sqlInsert = "insert into felhasznalo(id, vezeteknev, keresztnev, email, telefonszam, felhasznalonev, jelszo)
                          values(0, :vezeteknev, :keresztnev, :email, :telefonszam, :felhasznalonev, :jelszo)";
            $stmt = $dbh->prepare($sqlInsert); 
            $stmt->execute(array(':vezeteknev' => $_POST['f_name'], ':keresztnev' => $_POST['l_name'],
                                 ':email' => $_POST['email'], ':telefonszam' => $_POST['phone'], 'felhasznalonev' => $_POST['rusername'], ':jelszo' => sha1($_POST['rpassword1']))); 
            if($count = $stmt->rowCount()) {
                $newid = $dbh->lastInsertId();
                $uzenet = "A regisztrációja sikeres.<br>Azonosítója: {$newid}";                     
                $ujra = false;
            }
            else {
                $uzenet = "A regisztráció nem sikerült.";
                $ujra = true;
            }
        }
        }
    }
    catch (PDOException $e) {
        $uzenet = "Hiba: ".$e->getMessage();
        $ujra = true;
    }      
}
else {
    header("Location: .");
}
?>