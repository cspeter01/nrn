<?php
$ablakcim = array(
    'cim' => 'Nemzeti Reorganizációs Nonprofit Kft.',
);

$fejlec = array(
    'kepforras' => 'logo.png',
    'kepalt' => 'logo',
	'cim' => 'Mini honlap',
	'motto' => ''
);

$lablec = array(
    'copyright' => 'Copyright '.date("Y").'.',
    'ceg' => 'Eredeti weboldal:  <a href="https://www.nrn.hu/index.php">www.nrn.hu</a>'
);

$mappa = 'images/cats/';
$tipusok = array('.jpg', '.png');
$mediatipusok = array('iamges/jpeg', 'images/png');
$datumforma = "Y.m.d H:i";

$kepek = array();
$olvaso = opendir($mappa);
while (($fajl = readdir($olvaso)) !== false) {
 if (is_file($mappa.$fajl)) {
 $vege = strtolower(substr($fajl, strlen($fajl)-4));
 $kepek[$fajl] = filemtime($mappa.$fajl);
 }
}
closedir($olvaso);

$oldalak = array(
	'/' => array('fajl' => 'cimlap', 'szoveg' => 'KEZDŐLAP', 'menun' => array(1,1)),
	'galleria' => array('fajl' => 'galleria', 'szoveg' => 'GALÉRIA', 'menun' => array(1,1)),
	'media' => array('fajl' => 'media', 'szoveg' => 'MÉDIA', 'menun' => array(1,1)),
	'kapcsolat' => array('fajl' => 'kapcsolat', 'szoveg' => 'KAPCSOLAT', 'menun' => array(1,1)),
    'tablazat' => array('fajl' => 'tablazat', 'szoveg' => 'TÁBLÁZAT', 'menun' => array(0,1)),
    'belepes' => array('fajl' => 'belepes', 'szoveg' => 'BELÉPÉS', 'menun' => array(1,0)),
    'kilepes' => array('fajl' => 'kilepes', 'szoveg' => 'KILÉPÉS', 'menun' => array(0,1)),
    'belep' => array('fajl' => 'belep', 'szoveg' => '', 'menun' => array(0,0)),
    'regisztral' => array('fajl' => 'regisztral', 'szoveg' => '', 'menun' => array(0,0))
);

$hiba_oldal = array ('fajl' => '404', 'szoveg' => 'A keresett oldal nem található!');
?>