window.onload = function(){
	if (document.getElementById("aside").offsetHeight >  document.getElementById("main").offsetHeight)
	{
		var height = document.getElementById("aside").offsetHeight;
		document.getElementById("main").style.height = height + "px";
	}
}

