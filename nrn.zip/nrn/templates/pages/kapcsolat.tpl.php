        <article>
          <p>
            <h2>Elérhetőségeink</h2>
          </p>
          <p>
            Nemzeti Reorganizációs Nonprofit Kft.
          </p>
          <p>
            Székhely:<br>
            <address>1097 Budapest, Könyves Kálmán körút 12-14.</address><br> 
          </p>
          <p>
            Levelezési cím:<br>
            1453 Budapest, Pf.: 44.<br>
          </p>
          <p>
            Telefon:<br>
            +36 30 923 6508, +36 30 923 6578<br>
          </p>
          <p>
            Fax:<br>
            (+36 1)  210-0425<br>
          </p>
          <p>
            Email:<br>
            info@nrn.hu<br>
          </p>
        </article>
        <article>
          <form action="logicals/kiir.php" method="POST">
          <fieldset>
            <legend>Email küldés</legend>
            <label for="email2">Email cím</label><br><input type="email" name="email2" id="email2" required><br>
            <label for="nev2">Név</label><br><input type="text" name="nev2" id="nev2" required><br>
            <label for="uzenet2">Üzenet</label><br><input type="text" name="uzenet2" id="uzenet2" required><br>
            <input type="submit" value="Küld" name="kuld2" id="kuld2">
          </fieldset>
        </form>
        </article>

