        <article>
          <?php
          arsort($kepek);
          foreach($kepek as $fajl => $datum)
          {
          ?>
            <div class="kep">
            <a href="<?php echo $mappa.$fajl ?>" title="<?php echo 'Név: ' .$fajl. ', '; ?><?php echo 'Dátum: '  .date($datumforma, $datum); ?>">
            <img src="<?php echo $mappa.$fajl ?>">
            </a>
            </div>
          <?php
          }
          ?>

          <?php
          if(isset($_POST["kuld"])) {
          $target_dir = "images/cats/";
          $target_file = $target_dir . basename($_FILES["kepfeltolt"]["name"]);
          $uploadOk = 1;
          $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
          
             $check = getimagesize($_FILES["kepfeltolt"]["tmp_name"]);
          if($check !== false) {
            $uploadOk = 1;
            } else {
              $uploadOk = 0;
            }
          if (file_exists($target_file)) {
            $uploadOk = 0;
          }
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
          echo "Csak .jpg, .png, .jpeg, és gif kiterjesztés engedélyezett!";
          $uploadOk = 0;
        }
        if ($uploadOk == 0) {
        } else {
           if (move_uploaded_file($_FILES["kepfeltolt"]["tmp_name"], $target_file)) {
          } else {
          }
      }
    }
          ?>

          <div action="megoldás2/index.php" class="feltolt_sav">
            <form method="post" enctype="multipart/form-data"> 
              <input type="file" name="kepfeltolt" required><br>
              <input type="submit" name="kuld" value="+"> 
            </form>  
          </div>
        </article>
