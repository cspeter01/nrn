<article>
    <table>
        <tr>
            <th>ID</th>
            <th>Név</th>
            <th>Email</th>
            <th>Üzenet</th>
        </tr>
        <?php
            $servername = "localhost";
            $username = "beadando1";
            $password = "jelszo123";
            $dbname = "beadando1";
            $conn = new mysqli($servername, $username, $password, $dbname);
            mysqli_set_charset($conn,"utf8");
            if ($conn->connect_error) {
                die("Csatlakozási hiba: " . $conn->connect_error);
            } 
            $sql = "select id, nev, email, uzenet from uzenetek";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr><td> " . $row["id"]. "</td>";
                echo "<td> " . $row["nev"]. "</td>";
                echo "<td> " . $row["email"]. "</td>";
                echo "<td> " . $row["uzenet"]. "</td></tr>";
            }
        }
            $conn->close();
        ?>
    </table>
</article>